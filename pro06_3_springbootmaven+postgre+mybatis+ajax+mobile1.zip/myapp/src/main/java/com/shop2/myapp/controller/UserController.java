package com.shop2.myapp.controller;

public class UserController {

}
