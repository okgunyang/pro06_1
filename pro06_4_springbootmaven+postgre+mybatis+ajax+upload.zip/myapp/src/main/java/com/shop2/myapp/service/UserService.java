package com.shop2.myapp.service;

public interface UserService {

}
