package com.shop2.myapp.dto;

public class UserDTO {

}
