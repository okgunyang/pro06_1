package com.shop2.myapp.model;

public class UserMapper {

}
